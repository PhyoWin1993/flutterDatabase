package com.example.dataBase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
