import 'package:dataBase/model/user.dart';
import 'package:flutter/material.dart';
import 'package:dataBase/util/database_helper.dart';
// import 'package:flutter/widgets.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var dbs = new DatabaseHelper();
  int saveUs = await dbs.saveUser(new User("Mr Phyo", "Admin"));
  print("Save Data is  $saveUs");

  print("Save data");
  print("All ok");

  runApp(new MaterialApp(
    title: "DataBase Learnign",
    home: new Home(),
  ));
}

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Database Learn"),
        centerTitle: true,
        backgroundColor: Colors.deepOrangeAccent,
      ),
    );
  }
}
